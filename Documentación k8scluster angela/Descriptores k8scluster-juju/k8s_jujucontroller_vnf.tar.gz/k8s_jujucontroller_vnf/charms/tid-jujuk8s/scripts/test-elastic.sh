#!/bin/bash

CLUSTER_IP=192.168.0.151
ELASTIC_PORT=30280

curl -XPUT 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blog/user/jose' -H 'Content-Type: application/json' -d '{ "name" : "Jose" }'

curl -XPUT 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/1' -H 'Content-Type: application/json' -d '
{
    "user": "jose",
    "postDate": "2011-12-15",
    "body": "Search is hard. Search should be easy." ,
    "title": "On search"
}'

curl -XPUT 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/2' -H 'Content-Type: application/json' -d '
{
    "user": "jose",
    "postDate": "2011-12-12",
    "body": "Distribution is hard. Distribution should be easy." ,
    "title": "On distributed search"
}'

curl -XPUT 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/3' -H 'Content-Type: application/json' -d '
{
    "user": "jose",
    "postDate": "2011-12-10",
    "body": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat" ,
    "title": "Lorem ipsum"
}'


curl -XGET 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blog/user/jose?pretty=true'
curl -XGET 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/1?pretty=true'
curl -XGET 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/2?pretty=true'
curl -XGET 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/3?pretty=true'
curl 'http://'${CLUSTER_IP}':'${ELASTIC_PORT}'/blogpost/post/_search?q=user:jose&pretty=true'

