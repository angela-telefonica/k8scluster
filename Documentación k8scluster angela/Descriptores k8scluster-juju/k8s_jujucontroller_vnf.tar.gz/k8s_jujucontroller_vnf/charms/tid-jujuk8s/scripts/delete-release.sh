#!/bin/bash
RELEASE=$1
helm delete --purge ${RELEASE}

