#!/bin/bash
REPO_NAME=$1
helm repo remove ${REPO_NAME}
helm repo update

