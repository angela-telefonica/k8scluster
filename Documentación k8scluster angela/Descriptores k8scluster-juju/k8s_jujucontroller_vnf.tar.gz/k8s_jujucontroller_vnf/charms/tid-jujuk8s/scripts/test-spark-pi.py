#!/usr/bin/python3

import pyspark
from pyspark.streaming import StreamingContext
#    Kafka
from pyspark.streaming.kafka import KafkaUtils
import random
from operator import add

#sc = pyspark.SparkContext('spark://192.168.0.151:32077')

conf = pyspark.SparkConf().setAll([('spark.executor.memory', '2g'), ('spark.executor.cores', '1'), ('spark.cores.max', '1'), ('spark.driver.memory','2g')])

conf.setMaster("spark://192.168.0.151:32077")
sc = pyspark.SparkContext(conf=conf)

# sc.setLogLevel("DEBUG")

partitions = 100
n = 100000 * partitions

def f(_):
    x = random.random() * 2 - 1
    y = random.random() * 2 - 1
    return 1 if x ** 2 + y ** 2 <= 1 else 0

count = sc.parallelize(range(1, n + 1), partitions).map(f).reduce(add)
print("Pi is roughly %f" % (4.0 * count / n))
sc.stop()
