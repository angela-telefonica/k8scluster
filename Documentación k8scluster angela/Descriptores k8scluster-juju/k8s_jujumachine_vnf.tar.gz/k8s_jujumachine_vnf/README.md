This is a VNF with 3 big VDUs intended to model 3 VMS that will become 
a simple K8s cluster. No configuration is applied. Configuration will be
done offline.

