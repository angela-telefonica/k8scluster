# Onboarding e instanciacion

```bash
osm nfpkg-create k8s_base_vnf.tar.gz
osm nfpkg-create k8s_juju_vnf.tar.gz
osm nspkg-create k8s_base_ns.tar.gz
osm ns-create --ns_name k8s --nsd_name k8s_base --vim_account ost9-canonical-fortville --config '{vld: [ {name: mgmtnet, vim-network-name: mgmt} ] }'
```

Esto despliega un NS (k8s\_base\_ns) con 1 VNF que corre Juju (k8s\_juju\_vnf) y 4 VNFs (k8s\_base\_vnf) que corren el cluster de K8s (1 master, 3 workers).

Llamaremos a las máquinas:

- JUJU
- NODE1
- NODE2
- NODE3
- NODE4

# Instalacion y bootstrap de Juju en la maquina donde corre juju (JUJU)

## Instalar juju

```bash
sudo snap install juju --classic --channel=2.6/stable
ssh-keygen
```

## Añadir cloud: tipo manual provider

```bash
# Copia la clave SSH localmente
ssh-copy-id ubuntu@<IP_JUJU>
juju add-cloud
    manual
    k8s
    ubuntu@<IP_JUJU>
```

## Crear controller

```bash
ssh-copy-id -i /home/ubuntu/.local/share/juju/ssh/juju_id_rsa ubuntu@<IP_JUJU>
#Equivalente a: cat /home/ubuntu/.local/share/juju/ssh/juju_id_rsa.pub >> .ssh/authorized_keys
juju bootstrap k8s jujuk8s
```

Esto crea un controller localmente en la propia máquina

Se puede chequear el estado de juju con:

```
juju status
```

# Agregar las maquinas a juju (manual provider mode)

Primero hay que copiar, desde JUJU, la clave SSH del controlador a los nodos (master y workers) del cluster.

```bash
#cat /home/ubuntu/.local/share/juju/ssh/juju_id_rsa.pub
#vi .ssh/authorized_keys
ssh-copy-id -i /home/ubuntu/.local/share/juju/ssh/juju_id_rsa ubuntu@<IP_NODE1>
ssh-copy-id -i /home/ubuntu/.local/share/juju/ssh/juju_id_rsa ubuntu@<IP_NODE2>
ssh-copy-id -i /home/ubuntu/.local/share/juju/ssh/juju_id_rsa ubuntu@<IP_NODE3>
ssh-copy-id -i /home/ubuntu/.local/share/juju/ssh/juju_id_rsa ubuntu@<IP_NODE4>
```

Luego, en JUJU, agregamos las maquinas al controlador de juju manualmente:

```bash
juju add-machine ssh:ubuntu@<IP_NODE1> --debug
juju add-machine ssh:ubuntu@<IP_NODE2> --debug
juju add-machine ssh:ubuntu@<IP_NODE3> --debug
juju add-machine ssh:ubuntu@<IP_NODE4> --debug
```

Miramos los identificadores de las maquinas y los anotamos.

```bash
juju machines
```

Si son las primeras maquinas que agregqamos, los ids serán 0, 1, 2, 3.

# Desplegar el cluster de K8s con el bundle

El bundle original no se puede usar tal cual porque asume que se va a desplegar en algún cloud, sin especificar maquinas.

```bash
#juju deploy charmed-kubernetes
#wget https://api.jujucharms.com/charmstore/v5/charmed-kubernetes/archive/bundle.yaml
#vi bundle.yaml
```

El bundle lo hemos editado para especificar qué aplicación corre en qué máquina.

Copiamos el bundle desde el repo osm-descriptors a JUJU:

```bash
scp osm-descriptors/tid/k8s/k8s_base_ns/bundle/bundle.yaml ubuntu@<IP_JUJU>
```

Desplegamos el bundle y miramos el estado:

```bash
juju deploy ./bundle.yaml --map-machines=existing,0=0,1=1,2=2,3=3
#juju deploy ./bundle.yaml --map-machines=existing,0=30,1=31,2=32,3=33
juju status
```

# Interacting with the Kubernetes cluster

En la máquina JUJU:

```bash
mkdir -p ~/.kube
juju scp kubernetes-master/0:config ~/.kube/config
sudo snap install kubectl --classic
kubectl cluster-info
```

# To access the K8s dashboard 

En la maquina JUJU:

```bash
juju config kubernetes-master enable-dashboard-addons=true
```

Se puede hacer accesible el dashboard con el siguiente comando kubectl:

```bash
kubectl proxy --address <IP_JUJU>
```

Y ahora puedes hacer un tunel SSH desde un PC a JUJU, y desde un navegador acceder al dashboard:

<http://localhost:8001/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/>

# Install and init Helm

## Install

```bash
sudo snap install helm --classic
```

## Init

```bash
# Optional. Create account for tiller
# kubectl --namespace kube-system create serviceaccount tiller
# kubectl create clusterrolebinding tiller-cluster-rule --clusterrole=cluster-admin --serviceaccount=kube-system:tiller
helm init
# helm init --service-account tiller --wait
# kubectl --namespace kube-system patch deploy tiller-deploy -p '{"spec":{"template":{"spec":{"serviceAccount":"tiller"}}}}'
kubectl get all --all-namespaces
```
